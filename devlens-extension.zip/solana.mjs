// Read-only Solana PDA/account decoding. Layout: pump-fun/pump-public-docs/idl/pump.json.
const ALPHABET='123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
export const PUMP_PROGRAM='6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P';
export const METADATA_PROGRAM='metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s';
export function b58(bytes){let n=0n;for(const x of bytes)n=n*256n+BigInt(x);let s='';while(n){s=ALPHABET[Number(n%58n)]+s;n/=58n;}for(const x of bytes){if(x)break;s='1'+s;}return s;}
export function un58(s){let n=0n;for(const c of s){const i=ALPHABET.indexOf(c);if(i<0)throw Error('Invalid Base58');n=n*58n+BigInt(i);}const b=[];while(n){b.unshift(Number(n%256n));n/=256n;}for(const c of s){if(c!=='1')break;b.unshift(0);}return Uint8Array.from(b);}
const P=2n**255n-19n,mod=x=>((x%P)+P)%P;
function pow(x,n){let r=1n;for(x=mod(x);n;n>>=1n,x=mod(x*x))if(n&1n)r=mod(r*x);return r;}
const D=mod(-121665n*pow(121666n,P-2n));
function onCurve(bytes){let y=0n;for(let i=31;i>=0;i--)y=y*256n+BigInt(bytes[i]&(i===31?127:255));if(y>=P)return false;const yy=mod(y*y),den=mod(D*yy+1n);if(!den)return false;const xx=mod((yy-1n)*pow(den,P-2n));return xx===0n || pow(xx,(P-1n)/2n)===1n;}
export async function findPDA(seeds,program){const key=un58(program);if(key.length!==32 || seeds.length>15 || seeds.some(s=>s.length>32))throw Error('Invalid PDA seeds');const tail=new TextEncoder().encode('ProgramDerivedAddress');for(let bump=255;bump>=0;bump--){const data=new Uint8Array([...seeds.flatMap(s=>[...s]),bump,...key,...tail]),hash=new Uint8Array(await crypto.subtle.digest('SHA-256',data));if(!onCurve(hash))return b58(hash);}throw Error('PDA not found');}
export const curveAddress=mint=>findPDA([new TextEncoder().encode('bonding-curve'),un58(mint)],PUMP_PROGRAM);
export const metadataAddress=mint=>findPDA([new TextEncoder().encode('metadata'),un58(METADATA_PROGRAM),un58(mint)],METADATA_PROGRAM);
function accountBytes(account,owner){if(account?.owner!==owner || !Array.isArray(account.data) || account.data[1]!=='base64')return null;try{return Uint8Array.from(atob(account.data[0]),c=>c.charCodeAt(0));}catch{return null;}}
export function decodeCurve(account){const b=accountBytes(account,PUMP_PROGRAM),disc=[23,183,248,55,96,216,172,96];if(!b || b.length<81 || !disc.every((v,i)=>b[i]===v) || b[48]>1)return null;return {creator:b58(b.slice(49,81)),complete:!!b[48]};}
export function decodeMetadata(account,mint){const b=accountBytes(account,METADATA_PROGRAM);if(!b || b.length<69 || b[0]!==4 || b58(b.slice(33,65))!==mint)return null;try{let offset=65;const view=new DataView(b.buffer,b.byteOffset,b.byteLength),str=()=>{const n=view.getUint32(offset,true);offset+=4;if(n>4096 || offset+n>b.length)throw Error('Invalid metadata');const s=new TextDecoder().decode(b.slice(offset,offset+n)).replace(/\0/g,'').trim();offset+=n;return s;};return {name:str(),symbol:str(),metadata:str()};}catch{return null;}}
